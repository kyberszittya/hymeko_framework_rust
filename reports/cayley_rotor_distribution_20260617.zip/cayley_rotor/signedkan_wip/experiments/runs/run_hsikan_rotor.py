"""HSiKAN with the inductive Cayley-rotor embedding, STRICT (train-only) triads.

The flagship signed-cycle KAN currently starts from a transductive
``nn.Embedding(n_nodes, d)`` table — the leakage channel the audit exposes. This
driver replaces it with the inductive rotor via the existing ``initial_h_v`` hook
on ``MultiLayerSignedKAN.encode_triads`` (no model surgery), making HSiKAN
inductive and leakage-free. Plan: docs/plans/2026-06-17-hsikan-rotor-leakage-free/.

LEAKAGE GATE (the load-bearing part): triads AND structural features are built from
TRAIN edges only; ``--shuffle-train-signs`` permutes the train signs before both,
and test AUROC must then fall to chance (~0.5). No headline until it does.

    python -m signedkan_wip.experiments.runs.run_hsikan_rotor \
        --dataset bitcoin_otc --embed rotor --seed 0 [--shuffle-train-signs]
"""
from __future__ import annotations

import argparse
import json

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import roc_auc_score

from signedkan_wip.src.baselines.cayley_rotor_baseline import (
    STRUCT_DIM,
    _structural_features,
)
from signedkan_wip.src.core.hyperedges import construct
from signedkan_wip.src.core.signedkan import (
    MultiLayerSignedKAN,
    MultiLayerSignedKANConfig,
    build_vertex_triad_incidence,
)
from signedkan_wip.src.core.train import build_edge_to_triads
from signedkan_wip.src.datasets import SignedGraph, load, split
from signedkan_wip.src.embeddings.cayley_rotor import CayleyRotorEmbedding

SHUFFLE_SEED_OFFSET = 100003  # same as run_baseline_audit, for comparability


def _edge_incidence(edges, e2t, n_triads, device):
    """Sparse (E, n_triads) mean-pool incidence: M[e,t] = 1/|triads(e)|."""
    rows, cols, vals = [], [], []
    for ei, e in enumerate(edges):
        ids = e2t.get((min(int(e[0]), int(e[1])), max(int(e[0]), int(e[1]))), [])
        if not ids:
            continue
        w = 1.0 / len(ids)
        for t in ids:
            rows.append(ei); cols.append(t); vals.append(w)
    if not rows:
        idx = torch.zeros((2, 0), dtype=torch.long)
        return torch.sparse_coo_tensor(idx, torch.zeros(0), (len(edges), n_triads)).to(device)
    idx = torch.tensor([rows, cols], dtype=torch.long)
    v = torch.tensor(vals, dtype=torch.float32)
    return torch.sparse_coo_tensor(idx, v, (len(edges), n_triads)).coalesce().to(device)


class RotorInjector(nn.Module):
    """structural features → Cayley-rotor → proj to ``hidden`` = ``initial_h_v``."""

    def __init__(self, hidden: int):
        super().__init__()
        self.emb = CayleyRotorEmbedding(n_blocks=max(1, hidden // 3),
                                        in_features=STRUCT_DIM)
        self.proj = nn.Linear(self.emb.embedding_dim, hidden)

    def forward(self, struct: torch.Tensor) -> torch.Tensor:
        return self.proj(self.emb(struct))


def _pair(e):
    return (min(int(e[0]), int(e[1])), max(int(e[0]), int(e[1])))


def run(dataset: str, seed: int, embed: str, shuffle: bool,
        n_epochs: int = 120, hidden: int = 32,
        head: str = "incidence", dedup: bool = False) -> dict:
    """``head``: 'incidence' (edge-triad pool — can't reach held-out edges) or
    'bilinear' (node-embedding endpoint head, n_layers=2 so the M_vt pool flows
    cycle info into h_v — reaches held-out edges). ``dedup``: drop test edges
    whose (u,v) also appears in train (the true held-out set; fixes the
    split-by-index overlap leak)."""
    torch.manual_seed(seed)
    np.random.seed(seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    g = load(dataset)
    tr, _va, te = split(g, seed=seed)
    e_tr, s_tr = g.edges[tr], g.signs[tr].copy()
    e_te, s_te = g.edges[te], g.signs[te]
    if shuffle:
        perm = np.random.default_rng(seed + SHUFFLE_SEED_OFFSET).permutation(len(s_tr))
        s_tr = s_tr[perm]
    if dedup:
        tr_pairs = {_pair(e) for e in e_tr}
        keep = np.array([_pair(e) not in tr_pairs for e in e_te])
        e_te, s_te = e_te[keep], s_te[keep]

    # STRICT: triads + features from TRAIN edges (post-shuffle) only.
    g_tr = SignedGraph(edges=e_tr, signs=s_tr, n_nodes=g.n_nodes)
    triads = construct(g_tr)
    triad_v = torch.tensor([t.v for t in triads], dtype=torch.long, device=device)
    triad_sigma = torch.tensor([t.sigma for t in triads], dtype=torch.long, device=device)
    n_tri = len(triads)

    bilinear = head == "bilinear"
    n_layers = 2 if bilinear else 1
    cfg = MultiLayerSignedKANConfig(n_nodes=g.n_nodes, n_layers=n_layers,
                                    hidden_dim=hidden, grid=5, k=3,
                                    use_bilinear=bilinear)
    model = MultiLayerSignedKAN(cfg).to(device)
    if bilinear:
        # The dead-start gamma (1e-3) is for joint training with a spline loss;
        # here the bilinear head is the only objective, so activate it.
        model.bilinear.gamma.data.fill_(1.0)
        M_vt = build_vertex_triad_incidence(triad_v.cpu().numpy(), g.n_nodes, device)
        e_tr_t = torch.from_numpy(e_tr.astype(np.int64)).to(device)
        e_te_t = torch.from_numpy(e_te.astype(np.int64)).to(device)
    else:
        e2t = build_edge_to_triads(triads)
        M_tr = _edge_incidence(e_tr, e2t, n_tri, device)
        M_te = _edge_incidence(e_te, e2t, n_tri, device)

    inj = RotorInjector(hidden).to(device) if embed == "rotor" else None
    struct_t = (torch.from_numpy(_structural_features(e_tr, s_tr, g.n_nodes)).to(device)
                if embed == "rotor" else None)
    params = list(model.parameters()) + (list(inj.parameters()) if inj else [])
    opt = torch.optim.Adam(params, lr=1e-3, weight_decay=1e-5)
    tgt = torch.from_numpy((s_tr == 1).astype(np.float32)).to(device)

    def logits_for(edges_t, M):
        ihv = inj(struct_t) if inj is not None else None
        if bilinear:
            _, h_v = model.encode_triads(triad_v, triad_sigma, M_vt,
                                         return_h_v=True, initial_h_v=ihv)
            return model.bilinear(h_v[edges_t[:, 0]], h_v[edges_t[:, 1]])
        temb = model.encode_triads(triad_v, triad_sigma, None, initial_h_v=ihv)
        return model.classifier(torch.sparse.mm(M, temb)).squeeze(-1)

    for _ in range(n_epochs):
        model.train()
        if inj is not None:
            inj.train()
        logits = logits_for(e_tr_t, None) if bilinear else logits_for(None, M_tr)
        loss = F.binary_cross_entropy_with_logits(logits, tgt)
        opt.zero_grad()
        loss.backward()
        opt.step()

    model.eval()
    with torch.no_grad():
        te_logits = logits_for(e_te_t, None) if bilinear else logits_for(None, M_te)
        probs = torch.sigmoid(te_logits).cpu().numpy()
    y = (s_te == 1).astype(int)
    auc = roc_auc_score(y, probs) if len(np.unique(y)) > 1 else float("nan")
    return dict(dataset=dataset, seed=seed, embed=embed, head=head, dedup=dedup,
                shuffle=shuffle, test_auroc=round(float(auc), 4),
                n_test=int(len(s_te)),
                n_params=int(sum(p.numel() for p in params)), n_triads=n_tri)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="bitcoin_otc")
    ap.add_argument("--embed", choices=["table", "rotor"], default="rotor")
    ap.add_argument("--head", choices=["incidence", "bilinear"], default="incidence",
                    help="bilinear = node-endpoint head (reaches held-out edges)")
    ap.add_argument("--dedup", action="store_true",
                    help="drop test edges whose (u,v) is also a train edge "
                         "(the true held-out set)")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--n-epochs", type=int, default=120)
    ap.add_argument("--shuffle-train-signs", action="store_true")
    args = ap.parse_args()
    r = run(args.dataset, args.seed, args.embed, args.shuffle_train_signs,
            n_epochs=args.n_epochs, head=args.head, dedup=args.dedup)
    print(f"  HSiKAN[{r['embed']:5s}/{r['head']:9s} dedup={int(r['dedup'])}] "
          f"{r['dataset']:<14} seed={r['seed']} shuffle={r['shuffle']}  "
          f"AUROC={r['test_auroc']:.4f}  params={r['n_params']:,}  "
          f"n_test={r['n_test']:,}")
    print(json.dumps(r))


if __name__ == "__main__":
    main()
