"""Tests for the Cayley-rotor embedding (signedkan_wip/src/embeddings/cayley_rotor.py).

Run: pytest -p no:randomly signedkan_wip/tests/test_cayley_rotor.py
"""
from __future__ import annotations

import pytest
import torch

from signedkan_wip.src.embeddings.cayley_rotor import (
    CayleyRotorEmbedding,
    cayley_to_unit_quat,
    quat_rotate,
)


# ── rotor algebra ─────────────────────────────────────────────────────

def test_cayley_map_is_unit_quaternion() -> None:
    torch.manual_seed(0)
    b = torch.randn(64, 5, 3) * 3.0          # large b stresses the normalisation
    q = cayley_to_unit_quat(b)
    norms = q.norm(dim=-1)
    assert torch.allclose(norms, torch.ones_like(norms), atol=1e-5)
    assert (q[..., 0] >= 0).all()            # scalar part from the "1" is non-negative


def test_zero_bivector_is_identity_rotor() -> None:
    b = torch.zeros(3, 4, 3)
    q = cayley_to_unit_quat(b)
    ident = torch.tensor([1.0, 0.0, 0.0, 0.0])
    assert torch.allclose(q, ident.expand_as(q), atol=1e-6)


def test_rotation_preserves_norm() -> None:
    torch.manual_seed(1)
    b = torch.randn(32, 3)
    q = cayley_to_unit_quat(b)
    v = torch.randn(32, 3)
    rv = quat_rotate(q, v)
    assert torch.allclose(rv.norm(dim=-1), v.norm(dim=-1), atol=1e-5)


def test_quat_rotate_rejects_bad_shape() -> None:
    with pytest.raises(ValueError):
        quat_rotate(torch.zeros(2, 4), torch.zeros(2, 4))


# ── embedding module ──────────────────────────────────────────────────

def test_transductive_identity_at_init_equals_reference() -> None:
    # bivectors init to 0 → identity rotor → embedding == tiled reference.
    m = CayleyRotorEmbedding(n_blocks=4, n_items=10)
    e = m(torch.arange(10))
    ref = m.reference.detach().reshape(-1)
    assert e.shape == (10, 12)
    assert torch.allclose(e[0], ref, atol=1e-6)


def test_inductive_output_shape_and_sphere() -> None:
    m = CayleyRotorEmbedding(n_blocks=6, in_features=16)
    x = torch.randn(8, 16)
    e = m(x).reshape(8, 6, 3)
    assert e.shape == (8, 6, 3)
    # every 3-block sits on its block's reference sphere
    ref_norm = m.reference.detach().norm(dim=-1)            # (6,)
    assert torch.allclose(e.norm(dim=-1), ref_norm.expand(8, 6), atol=1e-5)


def test_gradient_flows_both_modes() -> None:
    for kw in (dict(n_items=5), dict(in_features=7)):
        m = CayleyRotorEmbedding(n_blocks=3, **kw)
        x = torch.arange(5) if "n_items" in kw else torch.randn(5, 7)
        loss = m(x).pow(2).sum()
        loss.backward()
        trained = m.bivectors if m.bivectors is not None else m.proj.weight
        assert trained.grad is not None and torch.isfinite(trained.grad).all()
        assert m.reference.grad is not None


def test_inductive_param_count_is_item_count_free() -> None:
    # The whole point: inductive params do NOT grow with the item count, so they
    # beat a dense nn.Embedding(n_items, d) table for large vocabularies.
    small = CayleyRotorEmbedding(n_blocks=8, in_features=32).n_parameters()
    # a transductive table for 100k items at the same width:
    dense_table = 100_000 * (3 * 8)
    assert small < dense_table
    # and inductive count is independent of any item count (no item axis at all)
    assert CayleyRotorEmbedding(n_blocks=8, in_features=32).n_parameters() == small


def test_rejects_both_or_neither_mode() -> None:
    with pytest.raises(ValueError):
        CayleyRotorEmbedding(n_blocks=4)                        # neither
    with pytest.raises(ValueError):
        CayleyRotorEmbedding(n_blocks=4, n_items=3, in_features=3)  # both
