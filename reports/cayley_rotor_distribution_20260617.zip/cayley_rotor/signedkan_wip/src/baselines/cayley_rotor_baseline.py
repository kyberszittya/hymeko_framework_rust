"""Cayley-rotor signed-link baseline — the inductive, leakage-free node feature.

This is DADSGNN's signed message-passing (reused: ``SGCNLayer`` + ``build_signed_adj``)
with its **transductive** ``nn.Embedding(n_nodes, d)`` table replaced by an
**inductive** Cayley-rotor embedding computed from train-only structural node
features. The embedding axis is the only difference, so a head-to-head against
``dadsgnn`` isolates exactly what the rotor buys:

  * inductive: no per-node identity table, so it transfers and does not memorise;
  * leakage-free: the node-ID table is the memorisation channel of the leakage
    audit ([[project-nature-leakage-paper]]); structural features remove it;
  * parameter-light: the table (``n_nodes * hidden`` params) is dropped for a
    tiny shared linear (``struct_dim * d``), item-count-free.

Strict invariant preserved: ``build_context`` receives train-only edges/signs,
and the structural features are computed from those alone.
"""
from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from signedkan_wip.src.embeddings.cayley_rotor import CayleyRotorEmbedding

from .registry import (
    GraphMeta,
    HParams,
    SignedLinkBaseline,
    SignedLinkModule,
    register,
)
from .sgcn_model import SGCNLayer, build_signed_adj

# Width of the inductive structural feature vector built by `_structural_features`.
STRUCT_DIM = 6


def _structural_features(
    edges: np.ndarray, signs: np.ndarray, n_nodes: int
) -> np.ndarray:
    """Per-node inductive features from the (train-only) signed degree profile.

    Returns ``(n_nodes, STRUCT_DIM)`` float32: log-degree, log-pos-degree,
    log-neg-degree, positive fraction, negative fraction, and signed balance
    ``(pos-neg)/deg``. These are functions of local structure, not node identity,
    so they carry no memorisation channel.
    """
    deg = np.zeros(n_nodes, dtype=np.float64)
    pos = np.zeros(n_nodes, dtype=np.float64)
    neg = np.zeros(n_nodes, dtype=np.float64)
    for (u, v), s in zip(edges, signs):
        deg[u] += 1.0
        deg[v] += 1.0
        if s > 0:
            pos[u] += 1.0
            pos[v] += 1.0
        else:
            neg[u] += 1.0
            neg[v] += 1.0
    eps = 1e-6
    feats = np.stack([
        np.log1p(deg), np.log1p(pos), np.log1p(neg),
        pos / (deg + eps), neg / (deg + eps), (pos - neg) / (deg + eps),
    ], axis=1)
    return feats.astype(np.float32)


class CayleyRotorSignedModel(SignedLinkModule):
    """Inductive rotor features → signed message passing → per-node embedding."""

    def __init__(self, in_features: int, hidden: int = 32, n_layers: int = 2):
        super().__init__()
        n_blocks = max(1, hidden // 3)
        self.emb = CayleyRotorEmbedding(n_blocks=n_blocks, in_features=in_features)
        self.proj = nn.Linear(self.emb.embedding_dim, hidden)
        self.layers = nn.ModuleList([
            SGCNLayer(in_dim=hidden, out_dim=hidden, first=(i == 0))
            for i in range(n_layers)
        ])
        self.classifier = nn.Sequential(
            nn.Linear(4 * hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, 1),
        )

    def encode_nodes(self, feats, A_pos, A_neg) -> torch.Tensor:
        x = self.proj(self.emb(feats))          # inductive rotor features (n, hidden)
        h_B, h_U = x, x
        for layer in self.layers:
            h_B, h_U = layer(h_B, h_U, A_pos, A_neg)
        return torch.cat([h_B, h_U], dim=-1)    # (n, 2*hidden)


@register("cayley_rotor")
class CayleyRotorBaseline(SignedLinkBaseline):
    def build_model(self, meta: GraphMeta, hp: HParams):
        return CayleyRotorSignedModel(
            in_features=STRUCT_DIM, hidden=hp.hidden, n_layers=hp.n_layers,
        )

    def build_context(self, edges, signs, n_nodes, device):
        feats = _structural_features(edges, signs, n_nodes)
        feats_t = torch.from_numpy(feats).to(device)
        a_pos, a_neg = build_signed_adj(edges, signs, n_nodes, device)
        return (feats_t, a_pos, a_neg)

    def default_hparams(self) -> HParams:
        return HParams(hidden=32, n_layers=2)


# --- + k-cycle features (the convergence step: structure over identity) ------

# Which signed-cycle arities to count per node. k=3 (triangles) is the core
# balance-theory primitive and cheap; higher k explode (see n_tuples cap note),
# so they are enumerated under a cap.
CYC_KS = (3,)
CAP_PER_K = 2_000_000  # subsample guard for dense graphs (logged if hit)
CYC_DIM = STRUCT_DIM + 3 * len(CYC_KS)


def _cycle_features(
    edges: np.ndarray, signs: np.ndarray, n_nodes: int,
    ks=CYC_KS, cap: int | None = CAP_PER_K,
) -> np.ndarray:
    """Per-node signed-cycle participation: for each arity ``k``, the
    (log) count of *balanced* and *unbalanced* k-cycles the node sits in, plus
    the balanced fraction. Balanced = even number of negative edges (Davis).
    Reuses ``core.n_tuples.construct_k_arrays`` (the HSiKAN cycle pool); these
    are the beyond-WL signal a walk/message-passing model cannot count.

    Returns ``(n_nodes, 3 * len(ks))`` float32, train-only (inductive).
    """
    from signedkan_wip.src.core.n_tuples import construct_k_arrays
    from signedkan_wip.src.datasets.legacy import SignedGraph

    g = SignedGraph(edges=edges.astype(np.int64),
                    signs=signs.astype(np.int64), n_nodes=n_nodes)
    cols = []
    for k in ks:
        v, _sigma, edge_signs = construct_k_arrays(g, k, max_cycles=cap)
        bal = np.zeros(n_nodes, dtype=np.float64)
        unb = np.zeros(n_nodes, dtype=np.float64)
        v = np.asarray(v)
        if v.size:
            es = np.asarray(edge_signs)
            is_bal = ((es == -1).sum(axis=1) % 2 == 0)
            for j in range(v.shape[1]):
                np.add.at(bal, v[:, j][is_bal], 1.0)
                np.add.at(unb, v[:, j][~is_bal], 1.0)
        tot = bal + unb
        cols += [np.log1p(bal), np.log1p(unb), bal / (tot + 1e-6)]
    return np.stack(cols, axis=1).astype(np.float32)


class CayleyRotorJumpModel(SignedLinkModule):
    """Rotor (degree features) → signed message passing, with the signed-cycle
    features **jumped past the SGCN** directly to the readout. The decomposition
    (reports/cyc_decompose) showed cycles-as-input are absorbed/redundant under
    message passing; this routes them around it so the readout sees the cycle
    signal undiluted (the highway-jump idea applied to cycles)."""

    def __init__(self, in_features: int, jump_features: int,
                 hidden: int = 32, n_layers: int = 2):
        super().__init__()
        n_blocks = max(1, hidden // 3)
        self.emb = CayleyRotorEmbedding(n_blocks=n_blocks, in_features=in_features)
        self.proj = nn.Linear(self.emb.embedding_dim, hidden)
        self.layers = nn.ModuleList([
            SGCNLayer(in_dim=hidden, out_dim=hidden, first=(i == 0))
            for i in range(n_layers)
        ])
        self.jump = nn.Linear(jump_features, hidden)
        self.classifier = nn.Sequential(
            nn.Linear(6 * hidden, hidden), nn.ReLU(), nn.Linear(hidden, 1),
        )

    def encode_nodes(self, deg, cyc, A_pos, A_neg) -> torch.Tensor:
        x = self.proj(self.emb(deg))
        h_B, h_U = x, x
        for layer in self.layers:
            h_B, h_U = layer(h_B, h_U, A_pos, A_neg)
        j = self.jump(cyc)                       # cycles jumped past the SGCN
        return torch.cat([h_B, h_U, j], dim=-1)  # (n, 3*hidden)


@register("cayley_rotor_jump")
class CayleyRotorJumpBaseline(CayleyRotorBaseline):
    """Cycles jumped to the readout (vs ``cayley_rotor_cyc`` which feeds them in
    at the bottom). Isolates whether jump-propagation un-redundants the cycle
    signal that message-passing otherwise absorbs."""

    def build_model(self, meta: GraphMeta, hp: HParams):
        return CayleyRotorJumpModel(
            in_features=STRUCT_DIM, jump_features=3 * len(CYC_KS),
            hidden=hp.hidden, n_layers=hp.n_layers,
        )

    def build_context(self, edges, signs, n_nodes, device):
        deg = _structural_features(edges, signs, n_nodes)
        cyc = _cycle_features(edges, signs, n_nodes)
        a_pos, a_neg = build_signed_adj(edges, signs, n_nodes, device)
        return (torch.from_numpy(deg).to(device),
                torch.from_numpy(cyc).to(device), a_pos, a_neg)


class SiGATRotorModel(SignedLinkModule):
    """SiGAT's motif attention (reused) with its transductive ``nn.Embedding``
    table replaced by the inductive Cayley-rotor on structural features. Tests
    H3: is the SiGAT advantage the *attention*, independent of the embedding? If
    this matches plain SiGAT, the rotor matches the best model at ~270x fewer
    params (the embedding was never the gap)."""

    def __init__(self, in_features: int, hidden: int = 32,
                 n_heads: int = 4, n_layers: int = 1):
        super().__init__()
        from .sigat_model import MotifAttention
        n_blocks = max(1, hidden // 3)
        self.emb = CayleyRotorEmbedding(n_blocks=n_blocks, in_features=in_features)
        self.proj = nn.Linear(self.emb.embedding_dim, hidden)
        self.layers = nn.ModuleList(nn.ModuleDict({
            "pos": MotifAttention(hidden, n_heads),
            "neg": MotifAttention(hidden, n_heads),
            "mix": nn.Linear(3 * hidden, hidden),
        }) for _ in range(n_layers))
        self.classifier = nn.Sequential(
            nn.Linear(2 * hidden, hidden), nn.ReLU(), nn.Linear(hidden, 1),
        )

    def encode_nodes(self, struct, pos_buckets, neg_buckets) -> torch.Tensor:
        h = self.proj(self.emb(struct))           # inductive rotor, not a table
        for layer in self.layers:
            h_pos = layer["pos"](h, pos_buckets)
            h_neg = layer["neg"](h, neg_buckets)
            h = F.relu(layer["mix"](torch.cat([h_pos, h_neg, h], dim=-1)))
        return h


@register("sigat_rotor")
class SiGATRotorBaseline(SignedLinkBaseline):
    def build_model(self, meta: GraphMeta, hp: HParams):
        return SiGATRotorModel(in_features=STRUCT_DIM, hidden=hp.hidden,
                               n_heads=hp.n_heads, n_layers=hp.n_layers)

    def build_context(self, edges, signs, n_nodes, device):
        from .sigat_model import build_neighbour_lists
        struct = _structural_features(edges, signs, n_nodes)
        pos, neg = build_neighbour_lists(edges, signs, n_nodes)
        return (torch.from_numpy(struct).to(device), pos, neg)

    def default_hparams(self) -> HParams:
        return HParams(hidden=32, n_layers=1, n_heads=4)  # SiGAT's recipe


@register("cayley_rotor_jump_k4")
class CayleyRotorJumpK4Baseline(CayleyRotorJumpBaseline):
    """Jump-propagated cycles at arities k=3 AND k=4 (richer cycle signal than
    triangles alone), now that jump-routing recovers the cycle signal. 4-cycles
    explode faster (see n_tuples cap note) — enumerated under the same cap."""

    K4_KS = (3, 4)

    def build_model(self, meta: GraphMeta, hp: HParams):
        return CayleyRotorJumpModel(
            in_features=STRUCT_DIM, jump_features=3 * len(self.K4_KS),
            hidden=hp.hidden, n_layers=hp.n_layers,
        )

    def build_context(self, edges, signs, n_nodes, device):
        deg = _structural_features(edges, signs, n_nodes)
        cyc = _cycle_features(edges, signs, n_nodes, ks=self.K4_KS)
        a_pos, a_neg = build_signed_adj(edges, signs, n_nodes, device)
        return (torch.from_numpy(deg).to(device),
                torch.from_numpy(cyc).to(device), a_pos, a_neg)


@register("cayley_rotor_cyc")
class CayleyRotorCycBaseline(CayleyRotorBaseline):
    """Rotor embedding on degree **+ signed-k-cycle** features --- the convergence
    A/B: does the (beyond-WL) cycle signal lift the rotor toward the attention
    baseline while staying parameter-light?"""

    def build_model(self, meta: GraphMeta, hp: HParams):
        return CayleyRotorSignedModel(
            in_features=CYC_DIM, hidden=hp.hidden, n_layers=hp.n_layers,
        )

    def build_context(self, edges, signs, n_nodes, device):
        deg = _structural_features(edges, signs, n_nodes)
        cyc = _cycle_features(edges, signs, n_nodes)
        feats_t = torch.from_numpy(np.concatenate([deg, cyc], axis=1)).to(device)
        a_pos, a_neg = build_signed_adj(edges, signs, n_nodes, device)
        return (feats_t, a_pos, a_neg)
