# HSMM arXiv Preprint — Priority Protection

## Status: URGENT

## Deadline
Submit **before April 19** (before SMC 2026 deadline).
Priority protection window is closing.

## Purpose
Establish timestamp priority for:
- HSMM 9-tuple formalization
- 6-primitive ISA (NAV, NEWV, NEWE, ATT, DET, MOVC)
- Turing completeness proof
- Expressiveness hierarchy: **Transformer ⊂ xLSTM ⊂ HSMM**
- FPGA kernel architecture targeting Xilinx Zynq UltraScale+

## Content Checklist
- [ ] Abstract — clear one-paragraph statement of contribution
- [ ] HSMM 9-tuple formal definition
- [ ] 6 primitives with operational semantics
- [ ] Turing completeness proof (complete, no gaps)
- [ ] Expressiveness hierarchy — strict inclusions proven
- [ ] FPGA kernel architecture diagram
- [ ] Related work (xLSTM, Transformer, graph transformation systems)
- [ ] Conclusion + future work pointer to SMC 2026

## Key Claims To Protect
1. HSMM as a computational model strictly above xLSTM
2. mLSTM matrix memory ↔ hypergraph incidence matrix correspondence
3. Transformer as degenerate hypergraph (dense attention)
4. 6-primitive ISA minimality

## arXiv Categories
Primary: `cs.LO` (Logic in Computer Science)
Secondary: `cs.NE` (Neural and Evolutionary Computing), `cs.AR` (Hardware Architecture)

## Notes
- SMC 2026 paper cites this as companion — must be live before SMC submission
- Do NOT wait for perfect — priority protection is the only goal here
