# IDEA: Actor-Critic-Evolver Agent Framework

## Status: PARKED — do not develop until after AVEC'26

## Core Insight
Do not say "AI integration."
Say: roles in a distributed system.

```
Actor    — observes IR state, queries structure
Critic   — evaluates IR against constraints/objectives
Mutator  — proposes and applies IR deltas
Evolver  — drives structural change over time
```

Roles are stable. Implementations (human, LLM, verifier, optimizer) swap freely.

## The IRAgent Abstraction

```rust
pub trait IRAgent {
    fn observe(&self, ir: &HyMeKoIR) -> Observation;
    fn propose(&self, obs: Observation) -> Vec<IRDelta>;
    fn criticize(&self, deltas: &[IRDelta]) -> Score;
}
```

Everything is an IRAgent:
- Human editor via WASM canvas
- Claude via MCP
- Lean 4 formal verifier (Critic)
- NAS optimizer (Evolver)
- Network fault detector (Actor)
- Raspberry Pi monitoring daemon (Actor)

## Connection to Established Formalisms

BDI Agents:
- Belief    → IR snapshot
- Desire    → objective function over IR state
- Intention → pending IRDelta batch

Multi-Agent Systems:
- Multiple agents on shared IR
- Conflict resolution → formal merge strategy (CRDT)
- Emergence → Evolver detects IR patterns network-wide

Actor Model (Hewitt):
- Messages → IRDeltas
- Actors → IRAgent peers
- No shared state → IR is the environment, not shared memory

## Why "Actor-Critic-Evolver" Not "AI"

"AI" is perishable marketing.
"Actor-Critic-Evolver protocol" is:
- Implementation-agnostic
- Formally grounded
- Ages well
- Connected to agent-based systemology literature

## The One-Sentence Description
"HyMeKo is a hypergraph-native IR where human engineers,
formal verifiers, and autonomous agents share a unified
Actor-Critic-Evolver protocol over a G-SPHF structure."

No mention of AI. Completely defensible.

## Publication Target
Agent-based systems venues:
- AAMAS (Autonomous Agents and Multi-Agent Systems)
- Connected to CogInfoCom via cognitive agent framing
- Systems engineering venues via MBSE + agent framing

## Prerequisite
- hymeko_mcp working
- P2P distributed IR stable
- At least two IRAgent implementations demonstrable
