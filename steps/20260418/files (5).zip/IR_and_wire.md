# HyMeKo IR and Wire Layer Architecture

## Core Principle
The IR is not a central store. It is a **distributed information unit** — a CRDT that can live anywhere, replicate, merge, and evolve across a network of peers.

## IR as CRDT

```rust
pub trait IRUnit {
    fn merge(&self, other: &Self) -> Self;       // deterministic merge
    fn delta(&self, other: &Self) -> IRDelta;    // atomic broadcast unit
    fn leq(&self, other: &Self) -> bool;         // partial order / lattice
}
```

## IRDelta — The Atomic Mutation

```rust
pub enum IRDelta {
    AddVertex(VertexData),
    RemoveVertex(VertexId),       // tombstone CRDT
    AddHyperEdge(EdgeData),
    MoveVertex(VertexId, Position),
    UpdateWeight(EdgeId, f64),
    AttachAttribute(VertexId, Attribute),
    DetachAttribute(VertexId, AttributeId),
}
```

## HSMM Primitives ↔ Distributed Operations

| HSMM Primitive | Distributed Meaning |
|---|---|
| NAV | traverse IR fragment graph |
| NEWV | local vertex creation → delta broadcast |
| NEWE | local hyperedge creation → delta broadcast |
| ATT | attach attribute → merge operation |
| DET | detach → tombstone CRDT |
| MOVC | move vertex → position delta |

## Wire Stack

```
HyMeKo IR (Rust structs)
    ↓ serde + ciborium
CBOR (RFC 8949) — binary, self-describing, deterministic mode
    ↓ bytes::Bytes view layer
Zero-copy buffer access (IRDeltaView<'a>)
    ↓ zstd dictionary compression (RFC 8878)
Compressed packets
    ↓ Reed-Solomon erasure coding (RFC 5510)
Fault-tolerant shards — topology-aware (by patch locality)
    ↓ iroh P2P (QUIC / RFC 9000)
Network peers
```

## Why CBOR (RFC 8949)

- IETF standard — citable in papers, no vendor dependency
- Self-describing — unknown nodes can forward without schema
- Deterministic encoding mode — required for CRDT checksumming
- Pure Rust (`ciborium`) — compiles to WASM cleanly
- `serde` integration — serialization nearly free
- Zero-copy achievable via view layer over `bytes::Bytes`

## Packet Header

```
┌────────────────────────────────────┐
│ magic:     u32  (0x484D4B4F)       │
│ version:   u16  (schema version)   │
│ ir_level:  u8   (G-SPHF level 0-8) │
│ flags:     u8   (compression etc.) │
│ patch_id:  u64                     │
│ delta_seq: u64  (CRDT sequence)    │
│ checksum:  u32  (xxhash3)          │
└────────────────────────────────────┘
```

## Zero-Copy View Layer

```rust
pub struct IRDeltaView<'a> {
    raw: &'a [u8],
    vertex_offset: usize,
    edge_offset: usize,
    patch_offset: usize,
}
```

Buffer owns memory. View holds offsets. No allocation per delta.

## Crate: `hymeko_wire`

```
hymeko_wire/
├── schema/         ← CBOR type definitions
├── shard.rs        ← topology-aware sharding by patch locality
├── compress.rs     ← zstd dictionary management
├── fec.rs          ← Reed-Solomon layer
└── view.rs         ← zero-copy IRDeltaView
```

## Dependencies

```toml
ciborium                 = "0.2"   # CBOR RFC 8949
bytes                    = "1"     # zero-copy buffer
serde                    = "1"     # derive layer
zstd                     = "0.13"  # RFC 8878
reed-solomon-erasure     = "6"     # RFC 5510
iroh                     = "0.26"  # QUIC P2P RFC 9000
```

## Standards Traceability

| Component | Standard |
|---|---|
| CBOR | RFC 8949 |
| zstd | RFC 8878 |
| Reed-Solomon | RFC 5510 |
| QUIC | RFC 9000 |

## Research Contribution
Topology-aware sharding by patch locality is novel — exploits G-SPHF structure to make fault recovery semantically meaningful. Publishable as systems paper.
