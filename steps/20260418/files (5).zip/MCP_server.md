# HyMeKo MCP Server

## Core Claim
First hypergraph-native Model Context Protocol server.
Any MCP-compatible LLM agent gains the ability to query and mutate a G-SPHF IR directly.

## The Formal Role Taxonomy (Not "AI Features")

```
Actor    — observes IR state, queries structure
Critic   — evaluates IR against constraints/objectives
Mutator  — proposes and applies IR deltas
Evolver  — drives structural change over time
```

These are roles in the system, not AI features.
Today a Mutator is Claude via MCP.
Tomorrow it could be a specialized HSMM process.
Roles are stable. Implementations swap.

## IRAgent Trait

```rust
pub trait IRAgent {
    fn observe(&self, ir: &HyMeKoIR) -> Observation;
    fn propose(&self, obs: Observation) -> Vec<IRDelta>;
    fn criticize(&self, deltas: &[IRDelta]) -> Score;
}
```

Human editor = IRAgent
Claude via MCP = IRAgent
Formal verifier = IRAgent (Critic)
NAS optimizer = IRAgent (Evolver)
Network fault detector = IRAgent (Actor)

All the same abstraction. Human and AI indistinguishable at interface level.

## MCP Tools Exposed (MVP)

```
add_vertex(name, level, properties)     → VertexId
add_hyperedge(vertices[], sign, weight) → EdgeId
apply_delta(IRDelta)                    → Result
apply_batch(Vec<IRDelta>)               → Result
snapshot()                              → JSON IR state
query_patch(patch_id)                   → patch details
emit_hymeko()                           → .hymeko text
emit_sysml()                            → SysML v2 text
emit_rust_stubs()                       → Rust trait skeletons
explain_structure()                     → natural language description
```

## Stack

```rust
// hymeko_mcp/src/main.rs
// ~100-200 lines for working MCP server
```

```toml
[dependencies]
rmcp    = { version = "0.1", features = ["server"] }
tokio   = { features = ["full"] }
serde_json = "*"
```

Transport: stdio (simplest) or SSE (for web clients)

## Capabilities This Unlocks

**Natural language → IR**
Describe a system in plain text →
Claude calls add_vertex, add_hyperedge →
IR builds up → canvas updates → SysML emits

**IR → natural language**
Claude calls snapshot, query_patch →
explains what the hypergraph structure means architecturally →
instant documentation

**Refactoring assistant**
"Move all Level 3 patches into a separate subsystem" →
Claude plans deltas → calls apply_batch →
entire model restructures

**Formal verification co-pilot**
Claude reads IR, identifies missing Lean 4 obligations,
generates proof templates, submits back via apply_delta

## Connection to P2P

In the distributed IR model, the MCP server is just another peer node.
Claude is an IRAgent operating on the shared hypergraph.
No special status — same protocol as every other agent.

## Publication Target
System demonstration paper: CogInfoCom 2026, MODELS 2026, or tool track.

```
Code:   ~200 lines Rust
Demo:   Claude adding vertices/hyperedges via natural language
Video:  screen recording
Paper:  4-6 pages, system track
```

## Estimated Build Time
One afternoon. `rmcp` crate makes this tractable immediately.

## Crate
```
hymeko_workspace/
└── hymeko_mcp/     ← MCP server (rmcp)
```
