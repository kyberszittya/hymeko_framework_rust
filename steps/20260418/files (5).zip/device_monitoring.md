# IDEA: HyMeKo Device Monitoring

## Status: PARKED — do not develop until after SMC 2026

## Why This First (Before Full Network Management)
- Bounded scope
- Immediately demonstrable on existing Raspberry Pi cluster
- Real industrial value
- Natural hypergraph structure
- Self-contained paper

## The Mapping

```
Device          → vertex
Sensor reading  → patch attribute
Dependency      → hyperedge (one failure affects N devices)
Alert state     → signed weight crossing threshold
State change    → HSMM primitive (ATT / DET)
```

## The First Monitored System
Your own Raspberry Pi home cloud:
- Forgejo
- k3s / Docker Swarm
- Nextcloud
- Qdrant
- WireGuard VPN

Build the tool ON the infrastructure it monitors.
Paper: "self-monitoring hypergraph infrastructure"

## Cascade Prediction (The Differentiator)

```
Traditional: device A down → alert on A
HyMeKo:      device A down → traverse hyperedges
             → predict impact on {B, C, D}
             → explain via patch topology
```

## Publication Target
CogInfoCom 2026 (already on radar for hymeko_neuro)
Could be combined application paper.

## Prerequisite
hymeko_server running on Raspberry Pi permanently.
Forgejo + k3s set up first.
