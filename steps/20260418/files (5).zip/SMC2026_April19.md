# IEEE SMC 2026 — Regular Paper

## Deadline: April 19, 2026 (HARD)

## Title (working)
"HyMeKo: A Hypergraph-Native Compilation Pipeline for Generalized Signed Patch Hypergraph Fields"

## Core Contribution
The HyMeKo compilation pipeline as a concrete realization of G-SPHF theory.

## Paper Structure
1. Introduction — motivation, round-trip engineering problem
2. Background — G-SPHF, GGK, HSMM (cite arXiv companion)
3. HyMeKo Architecture — workspace, crate structure, IR
4. Compilation Pipeline — T2M, M2T, synthesis targets
5. Evaluation — benchmark scenarios, structural overhead ratio (Proposition 1)
6. Related Work
7. Conclusion

## Key Citations
- Acta Polytechnica Hungarica (Vol. 23 No. 5, 2026) — published, cite directly
- HSMM arXiv preprint — must be live before submission
- GMDH (Ivakhnenko 1968) — historical lineage
- xLSTM — expressiveness comparison

## Checklist
- [ ] HSMM arXiv live (prerequisite)
- [ ] Introduction complete
- [ ] Architecture section complete
- [ ] Proposition 1 (structural overhead ratio) included
- [ ] Three benchmark scenarios
- [ ] Feature comparison table
- [ ] IEEE format, double-blind compliant
- [ ] References complete
- [ ] Proofread
- [ ] Submit

## Co-authors
- Ádám Csapó (primary collaborator)
- Check with Péter Galambos, Károly Széll re: contribution

## Notes
- Regular paper = 8 pages IEEE format
- Non-overlapping with IEEE COINS (already submitted)
