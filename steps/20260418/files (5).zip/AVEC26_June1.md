# AVEC'26 — Vehicle Dynamics Paper

## Deadline: June 1, 2026

## Venue
AVEC'26 — International Symposium on Advanced Vehicle Control
Tsukuba, Japan (aligned with Pannónia Scholarship Japan visit)

## Title (working)
"Lagrangian and Hamiltonian Vehicle Dynamics through Signed Hypergraph Formalism"

## Core Contribution
Demonstration that G-SPHF naturally expresses multi-body vehicle dynamics:
- Lagrangian mechanics recoverable from signed hypergraph structure
- Hamiltonian formulation as patch field over phase space
- Higher-order interaction terms handled natively (no workarounds)
- New results enabled by hypergraph formalism beyond classical treatment

## Why This Paper
1. Connects G-SPHF to geometric mechanics (serious field)
2. Japan venue alignment — automotive/robotics community
3. Establishes HyMeKo in control theory / autonomous vehicles domain
4. High-status application for career trajectory

## Key Mathematical Connections
- Abraham & Marsden — Foundations of Mechanics (ground truth reference)
- Geometric mechanics on hypergraph structures
- Signed weights ↔ generalized forces
- Patch topology ↔ configuration space decomposition

## Checklist
- [ ] Mathematical framework — Lagrangian on G-SPHF
- [ ] Hamiltonian formulation
- [ ] At least one classical result recovered
- [ ] At least one new result enabled by hypergraph formalism
- [ ] Simulation / numerical example
- [ ] AVEC format compliance
- [ ] Submit

## Co-authors
- Ádám Csapó
- Consider: Zoltán Szilágyi (vehicle dynamics domain expertise?)

## Strategic Notes
- Use this paper to introduce yourself to Japanese automotive research community
- Prof. Shohei Kato (Nagoya) and Prof. Mihoko Niitsuma (Chuo) — potential reviewers/collaborators
- This paper justifies the Japan visit scientifically
