# HyMeKo WASM Visual Editor

## Core Principle
Projectional editor. The IR is the single source of truth.
Text and graph canvas are two synchronized views. Never the other way around.

```
┌─────────────────────────────────────────────┐
│           HyMeKo IR (hymeko_core)           │
│                    ▲         ▲              │
│           M2T      │         │      T2M     │
│                    ▼         ▼              │
│         Text editor      Graph canvas       │
│                    ▲                        │
│                    │ emit                   │
│                    ▼                        │
│         SysML v2 / Rust stubs / Lean 4      │
└─────────────────────────────────────────────┘
```

## T2M / M2T — The Two Pure Functions

```rust
// model → text (always deterministic)
fn emit_text(model: &HyMeKoIR) -> String

// text → model (parser, graceful failure)
fn parse_text(src: &str) -> Result<HyMeKoIR, ParseError>
```

## Technology Stack

```
hymeko_core (Rust)
    ↓ wasm-pack + wasm-bindgen
hymeko_wasm (.wasm)
    ↓
React + SVG canvas (browser)
    ↓
hymeko_server (Axum, local)
    → serves WASM app
    → REST: read/write .sysml and .hymeko files
```

## Why WASM Not Tauri / JetBrains Plugin

- RustRover is primary IDE — JetBrains plugin = Kotlin/Java, wrong stack
- WASM compiles directly from hymeko_core — no FFI boundary
- Browser tab runs alongside RustRover naturally
- Zero installation for collaborators
- `ciborium` + `wasm-bindgen` = clean WASM compilation

## WASM API Surface

```rust
#[wasm_bindgen]
pub struct EditorSession {
    ir: HyMeKoIR,  // the real IR, not a copy
}

#[wasm_bindgen]
impl EditorSession {
    pub fn add_vertex(&mut self, ...) -> VertexId
    pub fn add_hyperedge(&mut self, ...) -> EdgeId
    pub fn apply_delta(&mut self, delta: JsValue)
    pub fn emit_hymeko(&self) -> String        // M2T
    pub fn emit_sysml(&self) -> String         // synthesis
    pub fn emit_rust_stubs(&self) -> String    // codegen
    pub fn parse(&mut self, src: &str) -> Result<(), JsValue>  // T2M
    pub fn snapshot(&self) -> JsValue          // canvas render data
}
```

## Hyperedge Rendering

Do NOT use React Flow or Cytoscape — binary edge libraries.
Render hyperedges natively in SVG:

```
Hyperedge connecting nodes A, B, C:
→ compute convex hull of {A, B, C} positions
→ render as filled polygon, low opacity + colored border
→ sign (±) → border color (blue = positive, red = negative)
→ weight → border thickness
```

Output is paper-ready. Same rendering as hypergraph publications.

## Threading Note
Audit hymeko_core for Rayon / std::thread before WASM build.
`wasm-bindgen-rayon` exists but requires careful configuration.

## Build Sprint

```
Sprint 1: in-memory model + emit_text + parse_text (pure Rust, no WASM)
Sprint 2: wasm-bindgen exposure + minimal React canvas
Sprint 3: text panel synchronized with canvas (T2M + M2T live)
Sprint 4: emit_sysml synthesis target
```

## Crate

```
hymeko_workspace/
├── hymeko_wasm/        ← wasm-bindgen exposure of IR
└── hymeko_server/      ← Axum: serves WASM + REST file I/O
```
