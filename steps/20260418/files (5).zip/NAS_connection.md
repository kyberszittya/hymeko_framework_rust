# IDEA: G-SPHF → Neural Architecture Search Connection

## Status: PARKED — do not develop until after AVEC'26

## The Insight
G-SPHF naturally describes neural architecture search spaces:
- Vertices = operations (conv, attention, pooling)
- Hyperedges = multi-input/output connections
- Patches = macro-architecture blocks
- Signed weights = skip connection polarity
- GGK kernel = architecture representation basis

GMDH (Ivakhnenko 1968) as first self-organizing hypergraph NAS
gives a 55-year historical lineage to this connection.

## Why This Is Non-Trivial
Current NAS methods use:
- DAG representations (binary edges only)
- Cell-based search spaces (limited topology)
- No formal geometric foundation

HyMeKo NAS would be:
- Hyperedge-native (higher-order op connections)
- Formally grounded in GGK geometry
- Searchable via HSMM primitives
- Verifiable via hymeko_verify

## Connection to HSMM Expressiveness Hierarchy
If Transformer ⊂ xLSTM ⊂ HSMM,
then NAS over HSMM search space finds architectures
that cannot be found by Transformer-space NAS.
That is a strong empirical claim worth testing.

## The Benchmark This Enables
Tasks where HSMM-trained models outperform Transformers.
This is the missing empirical evidence for the expressiveness hierarchy.
NAS is the experimental vehicle.

## Publication Target
NeurIPS / ICML / ICLR — top ML venues.
This is Phase 2 work but highest-impact theoretical direction.

## Prerequisite
- Expressiveness hierarchy proof bulletproof
- HSMM arXiv live
- hymeko_codegen capable of generating trainable architectures
