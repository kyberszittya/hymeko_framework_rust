# HyMeKo P2P Distributed IR

## Core Principle
The IR is not a central store.
It is an information unit that can live anywhere,
replicate, merge, and evolve across a network of peers.

## The Network

```
Node A (Alienware)        → heavy builds, FPGA, local LLM
Node B (PC 2021)          → WASM builds, browser testing
Node C (Raspberry Pi)     → Forgejo, Qdrant, infrastructure
Node D (Nagoya — Prof. Kato)  → collaboration
Node E (autonomous agent) → IRAgent peer

All holding IR fragments.
All applying IRDeltas.
All converging to consistent state.
No central server.
```

## CRDT Foundation

```rust
pub trait IRUnit {
    fn merge(&self, other: &Self) -> Self;       // deterministic
    fn delta(&self, other: &Self) -> IRDelta;    // atomic broadcast
    fn leq(&self, other: &Self) -> bool;         // lattice partial order
}
```

Eventual consistency by mathematical construction.
No coordination required.

## Gossip Protocol

```
Node receives IRDelta from peer
    ↓
Critic agent evaluates delta (optional policy check)
    ↓
merge() applied — always deterministic
    ↓
canvas / text view updates
    ↓
forward to other peers (gossip)
```

## Topology-Aware Sharding

Shards are not arbitrary byte ranges.
Vertices in the same G-SPHF patch → same shard.
Hyperedges → replicated across incident patch shards.

```rust
fn shard_by_patch(ir: &IRUnit) -> Vec<IRShard>
```

Fault recovery preserves local structure even when global state is partially lost.
This is the novel contribution in hymeko_wire.

## Two-Machine Strategy (Immediate)

```
Alienware                      PC 2021
─────────────────────────      ─────────────────────────
Heavy compilation              WASM builds
FPGA synthesis (Vivado)        Browser testing
LLM inference (local)          hymeko_server
hymeko_mcp server              Documentation builds
Rust release builds            Cross-platform CI
```

## Forgejo as Infrastructure Hub

```
Alienware ──push──▶ Forgejo (Raspberry Pi)
                        │
              ┌─────────┴─────────┐
              ▼                   ▼
         Alienware runner    PC 2021 runner
         (release builds,    (WASM builds,
          FPGA toolchain)     cross-platform)
```

Forgejo Actions = GitHub Actions compatible.
Single source of truth for HyMeKo workspace.

## Agent Roles in P2P Context

```
Actor    — local IR node, observes its fragment
Critic   — evaluates merge candidates before applying
Evolver  — proposes deltas that propagate network-wide
```

Not centralized services. Peers.
Each holds an IR fragment.
Each participates in distributed computation.

## Crates

```
hymeko_workspace/
├── hymeko_wire/    ← CBOR + zstd + Reed-Solomon + iroh
└── hymeko_p2p/     ← gossip protocol, peer discovery
```

## Connection to Network Management (Phase 3+)

```
Network topology     → hypergraph (subnets, VLANs)
Policy / ACL rules   → signed hyperedges (permit/deny)
Traffic flows        → patch fields
Fault propagation    → HSMM primitives
Config state         → IR mutations = network deltas
```

YANG/NETCONF/RESTCONF are tree-structured.
They cannot express higher-order network dependencies natively.
HyMeKo P2P could be semantic foundation for next-generation network digital twin.

## Historical Significance

Current distributed systems (Kafka, Kubernetes, IPFS) are built on
ad hoc combinations of binary graphs, flat key-value stores, tree configs.
None have a unified semantic foundation.

HyMeKo P2P would be the first distributed system where
data model, computation model, and distribution model are the same thing.
