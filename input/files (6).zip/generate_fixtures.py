#!/usr/bin/env python3
"""
generate_fixtures.py — synthetic HyMeKo fixture generator for the scaling study.

Produces three fixture families, sweeping size parameters along log-spaced ranges:

  chain(n)        : serial kinematic chain, n links + (n-1) revolute joints.
                    Lower-bound topology: every joint is arity-2, d̄ → 2.

  tree(n, k)      : rooted tree of n links with branching factor k,
                    (n-1) joints. Models realistic robot morphologies
                    (mobile base + arms + end-effectors).

  highArity(m, d) : synthetic structure with m hyperedges each of arity d,
                    stress-tests the storage-overhead asymptote ρ → 1
                    predicted by Proposition 4 for d̄ ≫ log n.

Usage:
    python generate_fixtures.py --out ./fixtures
    python generate_fixtures.py --out ./fixtures --sizes 1,5,10,100,1000

Each fixture is written to <out>/<family>/<name>.hymeko plus an index.json
manifest with (|V|, |E|, mean_arity, bytes) for each file — consumed later
by the benchmark harness and analysis script.
"""
from __future__ import annotations

import argparse
import json
import random
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable


# --------------------------------------------------------------------------- #
# Surface-language emission                                                   #
# --------------------------------------------------------------------------- #
# Templates mirror the surface syntax shown in Listing 1 of the SMC paper.
# If your grammar evolved, adjust LINK_TMPL and JOINT_TMPL here — nothing
# else in this file needs to change.

LINK_TMPL = (
    '  {name} : link <mass>{mass:.3f}</mass> '
    '{{ origin [[{ox:.3f}, {oy:.3f}, {oz:.3f}], [0.0, 0.0, 0.0]]; }}\n'
)

REVOLUTE_TMPL = (
    '  @{name} : revolute_arc (+ {parent}, - {child});\n'
)

HYPEREDGE_TMPL_PREFIX = '  @{name} : constraint ('

HEADER = (
    '{root_name} : kinematic {{ }}\n'
    '{{\n'
    '  world : link <mass>0.0</mass> {{ }}\n'
)

FOOTER = '}\n'


# --------------------------------------------------------------------------- #
# Dataclass: fixture stats                                                    #
# --------------------------------------------------------------------------- #

@dataclass
class FixtureStats:
    family: str
    name: str
    n_vertices: int    # |V|
    n_hyperedges: int  # |E|
    mean_arity: float  # d̄
    source_bytes: int
    path: str


# --------------------------------------------------------------------------- #
# Generators                                                                  #
# --------------------------------------------------------------------------- #

def gen_chain(n: int, seed: int = 0) -> tuple[str, FixtureStats]:
    """Serial chain: world → l0 → l1 → ... → l_{n-1} via revolute joints."""
    rng = random.Random(seed)
    root = f"chain_{n}"
    lines = [HEADER.format(root_name=root)]

    # links
    for i in range(n):
        lines.append(LINK_TMPL.format(
            name=f"l{i}", mass=rng.uniform(0.1, 5.0),
            ox=rng.uniform(-0.5, 0.5), oy=0.0, oz=i * 0.1,
        ))
    # joints (revolute, arity-2)
    lines.append(REVOLUTE_TMPL.format(name="j_root", parent="world", child="l0"))
    for i in range(n - 1):
        lines.append(REVOLUTE_TMPL.format(
            name=f"j{i}", parent=f"l{i}", child=f"l{i+1}"))
    lines.append(FOOTER)

    src = "".join(lines)
    n_v = n + 1                 # +1 for world
    n_e = n                     # n joints (including j_root)
    mean_arity = 2.0
    return src, FixtureStats(
        family="chain", name=f"chain_{n}", n_vertices=n_v,
        n_hyperedges=n_e, mean_arity=mean_arity,
        source_bytes=len(src.encode()), path="",
    )


def gen_tree(n: int, branching: int = 3, seed: int = 0) -> tuple[str, FixtureStats]:
    """Rooted tree: n links, branching factor k, (n-1)+1 revolute joints."""
    rng = random.Random(seed)
    root = f"tree_{n}_k{branching}"
    lines = [HEADER.format(root_name=root)]

    for i in range(n):
        lines.append(LINK_TMPL.format(
            name=f"l{i}", mass=rng.uniform(0.1, 5.0),
            ox=rng.uniform(-0.5, 0.5), oy=rng.uniform(-0.5, 0.5),
            oz=rng.uniform(0.0, 1.0),
        ))

    lines.append(REVOLUTE_TMPL.format(name="j_root", parent="world", child="l0"))
    # assign each link i≥1 a parent from earlier links, bounded by branching factor
    children_count = [0] * n
    for i in range(1, n):
        candidates = [p for p in range(i) if children_count[p] < branching]
        if not candidates:
            candidates = list(range(i))
        parent = rng.choice(candidates)
        children_count[parent] += 1
        lines.append(REVOLUTE_TMPL.format(
            name=f"j{i-1}", parent=f"l{parent}", child=f"l{i}"))
    lines.append(FOOTER)

    src = "".join(lines)
    n_v = n + 1
    n_e = n
    return src, FixtureStats(
        family="tree", name=f"tree_{n}_k{branching}", n_vertices=n_v,
        n_hyperedges=n_e, mean_arity=2.0,
        source_bytes=len(src.encode()), path="",
    )


def gen_high_arity(m: int, d: int, seed: int = 0) -> tuple[str, FixtureStats]:
    """
    Stress fixture for Prop 4: m hyperedges each of arity d, over a pool
    of ceil(m*d / 2) shared vertices (so vertices are reused across edges
    and ρ approaches 1 for large d).
    """
    rng = random.Random(seed)
    n_v = max(d + 1, (m * d) // 2)
    root = f"ha_m{m}_d{d}"
    lines = [HEADER.format(root_name=root)]

    for i in range(n_v):
        lines.append(LINK_TMPL.format(
            name=f"v{i}", mass=1.0, ox=0.0, oy=0.0, oz=0.0))

    # Each hyperedge: half of participants signed '+', half '-', plus one '~'
    for e in range(m):
        participants = rng.sample(range(n_v), d)
        half = d // 2
        plus = [f"+ v{participants[i]}" for i in range(half)]
        minus = [f"- v{participants[i]}" for i in range(half, 2 * half)]
        tilde = ([f"~ v{participants[-1]}"] if d % 2 == 1 else [])
        incidences = ", ".join(plus + minus + tilde)
        lines.append(f"  @e{e} : constraint ({incidences});\n")
    lines.append(FOOTER)

    src = "".join(lines)
    return src, FixtureStats(
        family="highArity", name=f"ha_m{m}_d{d}",
        n_vertices=n_v + 1, n_hyperedges=m, mean_arity=float(d),
        source_bytes=len(src.encode()), path="",
    )


# --------------------------------------------------------------------------- #
# Orchestration                                                               #
# --------------------------------------------------------------------------- #

DEFAULT_SIZES = [1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000]
DEFAULT_HA_ARITIES = [2, 3, 5, 10, 20, 50]
DEFAULT_HA_M = 200


def write_fixture(
    out_dir: Path, family: str, stats: FixtureStats, src: str
) -> FixtureStats:
    fam_dir = out_dir / family
    fam_dir.mkdir(parents=True, exist_ok=True)
    p = fam_dir / f"{stats.name}.hymeko"
    p.write_text(src, encoding="utf-8")
    stats.path = str(p.relative_to(out_dir))
    return stats


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", type=Path, required=True,
                    help="Output directory for fixtures and manifest")
    ap.add_argument("--sizes", type=str, default=None,
                    help="Comma-separated list of chain/tree sizes "
                         "(default: log-spaced 1..5000)")
    ap.add_argument("--arities", type=str, default=None,
                    help="Comma-separated arities for highArity family")
    ap.add_argument("--ha-m", type=int, default=DEFAULT_HA_M,
                    help="Hyperedge count for highArity family (default: 200)")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    sizes = ([int(x) for x in args.sizes.split(",")]
             if args.sizes else DEFAULT_SIZES)
    arities = ([int(x) for x in args.arities.split(",")]
               if args.arities else DEFAULT_HA_ARITIES)

    args.out.mkdir(parents=True, exist_ok=True)
    manifest: list[FixtureStats] = []

    # chain family
    for n in sizes:
        src, stats = gen_chain(n, seed=args.seed)
        manifest.append(write_fixture(args.out, "chain", stats, src))

    # tree family (branching factor 3, realistic robot morphology)
    for n in sizes:
        src, stats = gen_tree(n, branching=3, seed=args.seed)
        manifest.append(write_fixture(args.out, "tree", stats, src))

    # high-arity family (hold m fixed, sweep d)
    for d in arities:
        src, stats = gen_high_arity(args.ha_m, d, seed=args.seed)
        manifest.append(write_fixture(args.out, "highArity", stats, src))

    # write manifest
    (args.out / "index.json").write_text(
        json.dumps([asdict(s) for s in manifest], indent=2),
        encoding="utf-8",
    )
    print(f"Wrote {len(manifest)} fixtures to {args.out}/")
    print(f"Manifest: {args.out}/index.json")


if __name__ == "__main__":
    main()
