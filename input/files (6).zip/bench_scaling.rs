//! bench_scaling.rs — scaling benchmark harness for HyMeKo.
//!
//! Drop this into a binary crate that depends on your existing
//! `hymeko_core` / `hymeko_compiler` / `hymeko_emit` crates. Adjust the
//! THREE marked import paths to match your actual module names; the rest
//! is framework-agnostic.
//!
//! Output: a CSV file (default: scaling_results.csv) with one row per
//! (fixture × repetition), consumed by analyze_scaling.py for the
//! power-law fit and scaling-figure generation.
//!
//! Usage:
//!     cargo run --release --bin bench_scaling -- \
//!         --fixtures ./fixtures --out scaling_results.csv --reps 30
//!
//! Notes:
//! - Release profile, AVX2 lexer backend: match Section VI-A measurement
//!   conditions for apples-to-apples comparison with Table I.
//! - Single-threaded timing loop; no disk I/O for emit outputs (emit is
//!   into in-memory String). Disk I/O is excluded to isolate pipeline
//!   cost, consistent with the existing benchmark protocol.
//! - Wall-clock via std::time::Instant; per-iteration nanosecond
//!   granularity is sufficient for the fixture sizes swept.

use std::{
    fs,
    hint::black_box,
    path::{Path, PathBuf},
    time::Instant,
};

use serde::{Deserialize, Serialize};

// ======================================================================== //
// ADJUST THESE THREE LINES to match your workspace.                        //
// ======================================================================== //
use hymeko_compiler::compile;              // compile: &str -> Result<H, _>
use hymeko_core::Hypergraph as H;          // the canonical IR type
use hymeko_emit::{emit_urdf, emit_sdf, emit_gazebo_world,
                  emit_mjcf, emit_dot, emit_mermaid};
// ======================================================================== //

#[derive(Deserialize, Debug, Clone)]
struct FixtureEntry {
    family: String,
    name: String,
    n_vertices: usize,
    n_hyperedges: usize,
    mean_arity: f64,
    source_bytes: usize,
    path: String,
}

#[derive(Serialize)]
struct Row<'a> {
    family: &'a str,
    name: &'a str,
    n_vertices: usize,
    n_hyperedges: usize,
    mean_arity: f64,
    source_bytes: usize,
    rep: usize,
    stage: &'a str,          // "compile" | "urdf" | "sdf" | ...
    wall_ns: u128,
    output_bytes: usize,     // 0 for compile
}

fn time_once<F: FnOnce() -> R, R>(f: F) -> (R, u128) {
    let t0 = Instant::now();
    let r = f();
    let dt = t0.elapsed().as_nanos();
    (r, dt)
}

fn bench_fixture<W: std::io::Write>(
    writer: &mut csv::Writer<W>,
    fixtures_root: &Path,
    entry: &FixtureEntry,
    reps: usize,
) -> anyhow::Result<()> {
    let src_path = fixtures_root.join(&entry.path);
    let src = fs::read_to_string(&src_path)?;

    // warm-up: JIT'd caches, page residency, allocator warm-up.
    for _ in 0..3 {
        let h = compile(&src)?;
        black_box(emit_urdf(&h));
    }

    for rep in 0..reps {
        // compile
        let (h, dt_compile) = time_once(|| compile(&src).expect("compile"));
        writer.serialize(Row {
            family: &entry.family,
            name: &entry.name,
            n_vertices: entry.n_vertices,
            n_hyperedges: entry.n_hyperedges,
            mean_arity: entry.mean_arity,
            source_bytes: entry.source_bytes,
            rep, stage: "compile",
            wall_ns: dt_compile, output_bytes: 0,
        })?;

        // emit each format
        macro_rules! bench_emit {
            ($name:literal, $fn:ident) => {{
                let (out, dt) = time_once(|| $fn(&h));
                let out_str = out; // assume returns String or Vec<u8>
                let out_len = out_str.len();
                writer.serialize(Row {
                    family: &entry.family,
                    name: &entry.name,
                    n_vertices: entry.n_vertices,
                    n_hyperedges: entry.n_hyperedges,
                    mean_arity: entry.mean_arity,
                    source_bytes: entry.source_bytes,
                    rep, stage: $name,
                    wall_ns: dt, output_bytes: out_len,
                })?;
                black_box(out_str);
            }};
        }

        bench_emit!("urdf",    emit_urdf);
        bench_emit!("sdf",     emit_sdf);
        bench_emit!("gazebo",  emit_gazebo_world);
        bench_emit!("mjcf",    emit_mjcf);
        bench_emit!("dot",     emit_dot);
        bench_emit!("mermaid", emit_mermaid);
    }
    Ok(())
}

#[derive(clap::Parser)]
struct Args {
    #[arg(long)] fixtures: PathBuf,
    #[arg(long, default_value = "scaling_results.csv")] out: PathBuf,
    #[arg(long, default_value_t = 30)] reps: usize,
}

fn main() -> anyhow::Result<()> {
    use clap::Parser;
    let args = Args::parse();

    let manifest: Vec<FixtureEntry> = serde_json::from_str(
        &fs::read_to_string(args.fixtures.join("index.json"))?,
    )?;

    let mut writer = csv::Writer::from_path(&args.out)?;
    for entry in &manifest {
        eprintln!("bench: {} ({} V, {} E)",
            entry.name, entry.n_vertices, entry.n_hyperedges);
        bench_fixture(&mut writer, &args.fixtures, entry, args.reps)?;
        writer.flush()?;
    }
    eprintln!("done → {}", args.out.display());
    Ok(())
}
